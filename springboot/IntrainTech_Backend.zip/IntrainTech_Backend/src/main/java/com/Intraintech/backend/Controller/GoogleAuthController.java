package com.Intraintech.backend.Controller;public class GoogleAuthController {
}
