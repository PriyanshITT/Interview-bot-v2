package com.Intraintech.backend.payload.request;
public class MarksRequest {
    private int newMarks;

    // Getters and Setters
    public int getNewMarks() {
        return newMarks;
    }

    public void setNewMarks(int newMarks) {
        this.newMarks = newMarks;
    }
}
