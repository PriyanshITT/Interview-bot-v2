package com.Intraintech.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntrainTechApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntrainTechApplication.class, args);
	}

}
